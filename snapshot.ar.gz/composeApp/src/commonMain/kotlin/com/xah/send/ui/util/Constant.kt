package com.xah.send.ui.util

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object Constant {
    val CARD_NORMAL_DP : Dp = 2.5.dp
    val APP_HORIZONTAL_DP = 16.25.dp
    const val ANIMATION_SPEED = 400
}