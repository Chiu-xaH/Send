package com.xah.send.ui.model

// 入网状态
enum class LinkStatus {
    ERROR, OFF, ON
}