package com.xah.send.logic.model

enum class Platform {
    DESKTOP, ANDROID
}